* The data starts from Jan 14, 2020.

1.The COVID-19 China cases data are collected from DXY.cn and the data before Jan 22, we collected the data from Wuhan CDC.
2.We summarize cases by China province and city. 
3.We integrate the cases with China basemaps which are offered by China Data Instiute.

We provide China basemaps and update confirms, recovered, and deaths cases at least once a week. 